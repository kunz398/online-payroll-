<?php $__env->startSection('style'); ?>
    <style>
        #viewemp .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            max-width: 300px;
            margin: auto;
            text-align: center;
            font-family: arial;
        }

        .title {
            color: grey;
            font-size: 18px;
        }

        #viewemp a {
            text-decoration: none;
            font-size: 22px;
            color: black;
        }

        #editEmp, #deleteEmp {
            overflow: unset;
            opacity: 1;

            height: auto;
            /*max-width: 35%;*/
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="viewemp" class="container">
        
        <?php if(@$message !=NULL || @$message != ''): ?>
            <div class="alert alert-success" role="alert">
               <?php echo e($message); ?>

            </div>
        <?php endif; ?>
        <div class="row">

            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-4">
                    <div class="card">
                        <img src="<?php echo e(asset('images')); ?>/<?php echo e($data['picture']); ?>" alt="John" style="width:100%">
                        <h1><?php echo e($data['name']); ?></h1>
                        <p class="title"><?php echo e($data['role']); ?></p>
                        <p><?php echo e($data['email']); ?></p>
                        <div style="margin: 20px 0;">
                            <a href="#" class="clickEditIcon" data-id="<?php echo e($data['id']); ?>" data-toggle="tooltip" data-placement="top"
                               title="Edit User"><i class="fas fa-edit"></i></a>
                            &nbsp; &nbsp;
                            <a href="#" class="clickDeleteIcon" data-id="<?php echo e($data['id']); ?>" data-email="<?php echo e($data['email']); ?>" data-toggle="tooltip" data-placement="top" title="Remove User"><i
                                        class="fas fa-user-times"></i></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div id="editEmp" class="modal">
        <div class="modal-header"> Edit <span class="name_of_emp"><?php echo e($data['name']); ?></span></div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
            <p>Date Registered: dd/mm/yyyy</p>
        </div>
    </div>

    <div id="deleteEmp" class="modal">
        <div class="modal-header"> Delete <span class="name_of_emp"><?php echo e($data['name']); ?></span></div>
        <div class="modal-body">
            <button name="delete" id="delete" class="btn btn-danger" >Yes Delete</button>
            <button  name="cancel" id="cancel" class="btn btn-info" >No I Changed My Mind</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $('.clickEditIcon').on('click', function () {


            $("#editEmp").modal({
                fadeDuration: 200
            });
            let id = $(this).data("id");


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            /* Ajaxs*/
            $.ajax({
                url: "<?php echo e(route('edit_emp')); ?>",
                method: 'POST',
                data: {
                    id: id
                },
                success: function (data) {
                    $(".modal-body").html(data);
                }
            });
        });

        $('.clickDeleteIcon').on('click', function () {


            $("#deleteEmp").modal({
                fadeDuration: 200
            });
            let id = $(this).data("id");
            let email = $(this).data("email");

            $('#delete').on('click', function () {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                /* Ajaxs*/
                $.ajax({
                    url: "<?php echo e(route('delete_emp')); ?>",
                    method: 'POST',
                    data: {
                        id: id,
                        email:email
                    },
                    success: function (data) {

                    }
                });
            });
            $('#cancel').on('click', function () {
                $(".close-modal ").trigger('click');
            });




        });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\Desktop\Github\online-payroll-\resources\views/add_employee/viewEmp.blade.php ENDPATH**/ ?>