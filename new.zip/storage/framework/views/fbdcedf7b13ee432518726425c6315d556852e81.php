<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <table id="" class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
            <th>
                Period
            </th>

            <th>
                Net Pay
            </th>
            <th>
                View Detailed
            </th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($pay['pay_from']); ?> - <?php echo e($pay['pay_to']); ?>

                    </td>
                    <td>
                        <?php echo e(round($pay['net_pay'],2)); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(url('individual')); ?>/<?php echo e($pay['id']); ?>" class="btn btn-xs btn-outline-primary">View Details</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\My Second Desktop\Github\online-payroll-\resources\views/normaluser/index.blade.php ENDPATH**/ ?>