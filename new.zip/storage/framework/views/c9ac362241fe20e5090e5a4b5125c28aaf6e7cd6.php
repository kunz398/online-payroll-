<?php $__env->startSection('style'); ?>
    <style>
        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            max-width: 300px;
            margin: auto;
            text-align: center;
            font-family: arial;
        }

        .title {
            color: grey;
            font-size: 18px;
        }

        button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 8px;
            color: white;
            background-color: #000;
            text-align: center;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
        }

        a {
            text-decoration: none;
            font-size: 22px;
            color: black;
        }

        button:hover, a:hover {
            opacity: 0.7;
        }
        #editEmp{
            overflow: unset;
            opacity: 1;

            height: 51%;
            max-width: 35%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <img src="<?php echo e(asset('images/a.png')); ?>" alt="John" style="width:100%">
                    <h1>Name</h1>
                    <p class="title">Role</p>
                    <p>Email</p>
                    <div style="margin: 20px 0;">
                        <a href="#" id="clickEditIcon" data-toggle="tooltip" data-placement="top" title="Edit User"><i
                                    class="fas fa-edit"></i></a>
                        &nbsp; &nbsp;
                        <a href="#" data-toggle="tooltip" data-placement="top" title="Remove User"><i
                                    class="fas fa-user-times"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div id="editEmp" class="modal">
            <div class="modal-header"> Edit <span class="name_of_emp">__</span></div>
            <div class="modal-body">
                <form id="editFormEmp" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">

                        <label for="id"
                            class="col-md-4 col-form-label text-md-right"><?php echo e(__('text.emp')); ?> <?php echo e(__('text.id')); ?></label>
                        <div class="col-md-6 col-6">
                             <input id="id" type="text" class="form-control" name="id" value="id" autocomplete="off" readonly>
                        </div>
                        <label for="name"
                               class="col-md-4 col-form-label text-md-right"><?php echo e(__('text.emp')); ?> <?php echo e(__('text.name')); ?></label>
                        <div class="col-md-6 col-6">
                            <input id="name" type="text" class="form-control" name="id" value="name" autocomplete="off">
                        </div>
                    </div>

                    <div class="form-group row">

                        <label for="email"
                               class="col-md-4 col-form-label text-md-right"><?php echo e(__('text.emp')); ?> <?php echo e(__('text.email')); ?></label>
                        <div class="col-md-6 col-6">
                            <input id="email" type="text" class="form-control" name="email" value="email" autocomplete="off">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
        $('#clickEditIcon').on('click', function () {
            $("#editEmp").modal({
                fadeDuration: 200
            });
        });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\Desktop\paymaker\resources\views/add_employee/viewEmp.blade.php ENDPATH**/ ?>