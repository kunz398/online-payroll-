<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(@$message !=NULL || @$message != ''): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('post.week.starts')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label for="startson"
                   class="col-md-4 col-form-label text-md-right"><?php echo e(__('text.week')); ?> <?php echo e(__('text.starts')); ?> <?php echo e(__('text.on')); ?></label>
            <div class="col-md-6">
                <select id="startson" name="startson" class="browser-default custom-select">
                    <option value="Monday"><?php echo e(__('text.Monday')); ?></option>
                    <option value="Tuesday"><?php echo e(__('text.Tuesday')); ?></option>
                    <option value="Wednesday"><?php echo e(__('text.Wednesday')); ?></option>
                    <option value="Thursday"><?php echo e(__('text.Thursday')); ?></option>
                    <option value="Friday"><?php echo e(__('text.Friday')); ?></option>
                    <option value="Saturday"><?php echo e(__('text.Saturday')); ?></option>
                    <option value="Sunday"><?php echo e(__('text.Sunday')); ?></option>
                </select>
            </div>
            <button class="btn btn-outline-primary hvr-rotate" type="submit">Submit</button>
        </div>

        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Monday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hours_monday" autocomplete="off">
            </div>
        </div>

        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Tuesday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hours_tuesday" autocomplete="off">
            </div>
        </div>

        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Wednesday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hourse_wend" autocomplete="off">
            </div>
        </div>

        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Thursday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hourse_thursday" autocomplete="off">
            </div>
        </div>

        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Friday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hourse_friday" autocomplete="off">
            </div>
        </div>

        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Saturday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hourse_saturday" autocomplete="off">
            </div>
        </div>


        <div class="form-group row">
            <label for="amount"
                   class="col-md-4 col-form-label text-md-right">Normal Hours for <?php echo e(__('text.Sunday')); ?></label>
            <div class="col-md-6">
                <input class="form-control" type="text" value="" name="hourse_sunday" autocomplete="off">
            </div>

        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\My Second Desktop\Github\online-payroll-\resources\views/prefrence/index.blade.php ENDPATH**/ ?>