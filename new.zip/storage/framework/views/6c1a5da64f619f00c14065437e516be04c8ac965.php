<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(@$type == "emp"): ?>
            <div class="row">
                <div class="col-4">
                    <a class="custom-link"  href="<?php echo e(route('pay.view')); ?>"><div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header"></div>
                            <div class="card-body">
                                <h5 class="card-title"><i class="fab fa-cc-amazon-pay fa-2x"></i></h5>
                                <p class="card-text"> <?php echo e(__('text.view')); ?> <?php echo e(__('text.pay_slip')); ?>.</p>
                            </div>
                        </div>
                    </a>
                </div>


            </div>
        <?php else: ?>
            <div class="row">
            <div class="col-4">
             <a class="custom-link"  href="<?php echo e(route('add_emp')); ?>"><div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div class="card-header"><?php echo e(__('text.add')); ?> <?php echo e(__('text.emps')); ?></div>
                    <div class="card-body">
                        <h5 class="card-title"><i class="text-dark fas fa-user-plus fa-2x"></i></h5>
                        <p class="card-text"><?php echo e(__('text.add')); ?> <?php echo e(__('text.new')); ?> <?php echo e(__('text.emp')); ?>.</p>
                    </div>
                </div>
             </a>
            </div>

            <div class="col-4">
                <a class="custom-link"  href="<?php echo e(route('view_emp')); ?>"><div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                        <div class="card-header"><?php echo e(__('text.view')); ?> <?php echo e(__('text.emp')); ?></div>
                        <div class="card-body">
                            <h5 class="card-title"><i class="text-dark far fa-address-book fa-2x"></i></h5>
                            <p class="card-text"><?php echo e(__('text.view')); ?> <?php echo e(__('text.current')); ?> <?php echo e(__('text.registered')); ?> <?php echo e(__('text.emps')); ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-4">
                <a class="custom-link"  href="<?php echo e(route('index.calc')); ?>"><div class="card text-white mb-3" style="max-width: 18rem; background: #e4615d;">
                        <div class="card-header"><?php echo e(__('text.calc')); ?> <?php echo e(__('text.pay')); ?></div>
                        <div class="card-body">
                            <h5 class="card-title"><i class="text-dark fas fa-calculator fa-2x"></i></h5>
                            <p class="card-text"><?php echo e(__('text.calc')); ?> <?php echo e(__('text.emps')); ?> <?php echo e(__('text.pay')); ?> </p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        validationForm('myCheckBoxes', 'myCheckBoxesMsg', "required",'checkbox',false)
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\My Second Desktop\Github\online-payroll-\resources\views/dashboard.blade.php ENDPATH**/ ?>