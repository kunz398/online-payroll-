<?php $__env->startSection('style'); ?>
    <style>
        #customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td, #customers th {
          //  border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even){background-color: #f2f2f2;}

        #customers tr:hover {background-color: #ddd;}

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <table id="customers" class="text-center">
        <tr>
            <td colspan="4">
                <?php echo e($data['company_name']); ?>

            </td>
        </tr>
        <tr>
            <td>Date</td>
            <td><?php echo e($data['pay_to']); ?></td>
            <td>Position</td>
            <td><?php echo e($data['position']); ?></td>
        </tr>
        <tr>
            <td>
                Name:
            </td>
            <td>
                <?php echo e($data['name']); ?>

            </td>
        </tr>
        <tr>
            <td>
                Gross
            </td>
            <td>
                <?php echo e($data['gross_pay']); ?>

            </td>
            <td>
                Gross YTD
            </td>
            <td>
                <?php echo e($data['ytd_gross']); ?>

            </td>
        </tr>
        <tr>
            <td>
                Net
            </td>
            <td>
                <?php echo e($data['net_pay']); ?>

            </td>

            <td>
                Net YTD
            </td>
            <td>
                <?php echo e($data['ytd_net']); ?>

            </td>
        </tr>

    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\My Second Desktop\Github\online-payroll-\resources\views/normaluser/individual.blade.php ENDPATH**/ ?>