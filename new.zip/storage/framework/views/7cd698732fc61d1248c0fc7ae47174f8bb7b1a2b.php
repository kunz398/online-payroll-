<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center material_pink"><?php echo e(__('text.add')); ?> <?php echo e(__('text.deduction')); ?></div>

                    <div class="card-body">

                        <form id="deductionForm" method="POST" action="<?php echo e(route('updateDeduction')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="alert alert-light text-xl-center" role="alert">
                                    <strong class=""><?php echo e(__('text.deduction')); ?> <?php echo e(__('text.name')); ?></strong> <?php echo e($result->name); ?>

                                </div>
                                <input class="form-control" type="text" value="<?php echo e($result->id); ?>" name="id[]" readonly hidden>

                                <div class="form-group row">
                                    <label for="type"
                                           class="col-md-4 col-form-label text-md-right"><?php echo e(__('text.deduction')); ?> <?php echo e(__('text.type')); ?></label>
                                    <div class="col-md-6">
                                        <select id="type" class="form-control" name="type[]">
                                            <option value="%" <?php if($result->type == '%'): ?> selected <?php endif; ?>>%</option>
                                            <option value="$" <?php if($result->type == '$'): ?> selected <?php endif; ?>>$$</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="amount"
                                           class="col-md-4 col-form-label text-md-right"><?php echo e(__('text.deduction')); ?> <?php echo e(__('text.amount')); ?></label>
                                    <div class="col-md-6">
                                        <input class="form-control" type="text" value="<?php echo e($result->amount); ?>" name="amount[]" autocomplete="off">
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>No Deduction</p>
                            <?php endif; ?>
                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button id="" type="submit" name="submit" class="btn btn-outline-success" >
                                        <?php echo e(__('text.add')); ?> <?php echo e(__('text.deduction')); ?>

                                    </button>
                                    <br/>
                                </div>
                            </div>

                        </form>
                        <div class="container">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <i class="fas fa-exclamation-triangle"></i>
                                            <?php echo e($error); ?> <br />
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\My Second Desktop\Github\online-payroll-\resources\views/add_employee/deductionForm.blade.php ENDPATH**/ ?>