<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="post" action="<?php echo e(route('post.calc.pick.user')); ?>">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control custom-checkbox p-2">
                <input type="checkbox" class="custom-control-input" name="<?php echo e($data['id']); ?>" id="emp_<?php echo e($data['id']); ?>">

                <label class="custom-control-label" for="emp_<?php echo e($data['id']); ?>">
                    <img src="<?php echo e(asset('images')); ?>/<?php echo e($data['picture']); ?>" class="rounded-circle"
                         style="width: 74px; height: 57px;"
                    />
                    <span class="text-monospace">
                        <?php echo e($data['email']); ?>

                    </span>

                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="btn btn-outline-success"><i class="fas fa-infinity"></i> <?php echo e(__('text.calc')); ?> <?php echo e(__('text.pay')); ?></button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\Desktop\Github\online-payroll-\resources\views/add_employee/IndexCalc.blade.php ENDPATH**/ ?>