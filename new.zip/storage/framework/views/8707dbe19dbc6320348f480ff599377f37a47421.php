<?php $__env->startSection('style'); ?>
    <style>
        .weekDays-selector input[type=checkbox] {
            display: none!important;
        }

        .weekDays-selector input[type=checkbox] + label {
            /* display: inline-block; */
            border-radius: 6px;
            background: #dddddd;
            /* height: 40px; */
            width: 80px;
            margin-right: 10px;
            line-height: 40px;
            text-align: center;
            cursor: pointer;
        }

        .weekDays-selector input[type=checkbox]:checked + label {
            background: #f06292;
            color: #ffffff;
        }
        .hrsworked {

            width: 80px;
            margin-right: 10px;
            line-height: 40px;

        }

        .btn-outline-primary{
            color: #b39ddb;
            border-color: #b39ddb;
        }
        .btn-outline-primary:hover{
            background-color: #b39ddb!important;
            border-color: #b39ddb!important;
        }

        .btn-outline-primary:not(:disabled):not(.disabled):active, .btn-outline-primary:not(:disabled):not(.disabled).active, .show > .btn-outline-primary.dropdown-toggle{
            background-color: #b39ddb;
            border-color: #b39ddb;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row">
                <div class="col-12">
                    <div class="shadow-lg p-3 bg-white rounded text-center text-monospace"><?php echo e($data['email']); ?></div>
                    <?php if( $data['pay_cycle'] == "forthrightly"): ?>
                        <?php $size = 2; ?>
                    <?php elseif($data['pay_cycle'] =="monthly"): ?>
                        <?php $size = 4; ?>
                    <?php elseif($data['pay_cycle'] =="weekly"): ?>
                        <?php $size = 1; ?>
                    <?php endif; ?>
                    <?php for($i = 0; $i < $size; $i++): ?>
                        <div class="weekDays-selector p-5">
                            <div class="row">
                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="mon:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-mon<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-mon<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Monday</label>

                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="tue:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-tue<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-tue<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Tuesday</label>

                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="wed:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-wed<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-wed<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Wednesday</label>

                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="thu:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-thu<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-thu<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Thursday</label>

                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="fri:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-fri<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-fri<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Friday</label>

                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="sat:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-sat<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-sat<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Saturday</label>

                                <input type="checkbox" name="<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" value="sun:<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" id="weekday-sun<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>" class="weekday" />
                                <label for="weekday-sun<?php echo e($data['id']); ?>_week:<?php echo e($i); ?>">Sunday</label>
                            </div>

                            <div class="row">
                                <input type="text" name="mon" data-hrsofdays="mon_week:<?php echo e($i); ?>" id="hrs" placeholder="" class="hrsworked" value="">

                                <input type="text" name="tue" data-hrsofdays="tue_week:<?php echo e($i); ?>"  id="hrs" placeholder="" class="hrsworked" value="">

                                <input type="text" name="wed" data-hrsofdays="wed_week:<?php echo e($i); ?>"  id="hrs" placeholder="" class="hrsworked" value="">

                                <input type="text" name="thu" data-hrsofdays="thu_week:<?php echo e($i); ?>"  id="hrs" placeholder="" class="hrsworked" value="">

                                <input type="text" name="fri" data-hrsofdays="fri_week:<?php echo e($i); ?>"  id="hrs" placeholder="" class="hrsworked" value="">

                                <input type="text" name="sat" data-hrsofdays="sat_week:<?php echo e($i); ?>"  id="hrs" placeholder="" class="hrsworked" value="">

                                <input type="text" name="sun" data-hrsofdays="sun_week:<?php echo e($i); ?>"  id="hrs" placeholder="" class="hrsworked" value="">
                            </div>
                            <small style="position: absolute;bottom: 21px;left: 24%;">Hours Worked!</small>
                        </div>
                        <?php endfor; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <center>
            <button class="btn btn-outline-primary hvr-curl-bottom-left" id="genePay">Generate Pay</button>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $('#genePay').on('click',  function() {
            var daysCheckedByUsers = [];
            var hoursInputedByUsers = [];
            $.each($("input[class='weekday']:checked"), function(){
                daysCheckedByUsers.push($(this).val());
            });
            $(".hrsworked").each(function() {
                //if($(".hrsofdays").val() == '' || $(".hrsofdays").val() == null){

             //   }else {
                    hoursInputedByUsers.push($(this).data('hrsofdays'));
                    hoursInputedByUsers.push($(this).val());
                    hoursInputedByUsers.push("\n");
              //  }

            });
            console.log(hoursInputedByUsers);

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kunal\Desktop\Github\online-payroll-\resources\views/add_employee/ifAnyabsents.blade.php ENDPATH**/ ?>