<?php

    namespace App\Http\Controllers;

    use App\Deduction;
    use App\Preference;
    use App\User;
    use App\EmpDetail;
    use DateTime;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Hash;

    class AddUserController extends Controller
    {

        public function index()
        {
            //
        }

        public function AjaxsEditEmp(Request $request)
        {
            $id = $request->id;
            $data = [];
            $employees = EmpDetail::where('id',$id)->get();
            foreach ($employees as $employee)
            {
                $users = User::where('email',$employee->email)->get();

                foreach ($users as $user)
                {
                    $temp = array(
                        "id"=>$user->id,
                        "name"=>$user->name,
                        "role"=>$employee->role,
                        "email"=>$user->email,
                        "picture"=>$employee->pic,
                        "pay_cycle"=>$employee->pay_cycle,
                        "gross_pay"=>$employee->gross_pay,
                        "rate"=>$employee->rate,
                        "deductions"=>$employee->deductions
                    );
                }
                array_push($data, $temp);
            }

            $deduct = Deduction::where('emp_detail_id',$id)->get();
            return view('add_employee.editform')->with('datas',$data)->with('deducts',$deduct);
        }

        public function update_emp(Request $request)
        {
            $user = DB::table('users')
                ->where('id',  $request->emp_id)
                ->update([
                    'name' =>   $request->emp_name,
                    'email' => $request->emp_email
                ]);
            $emp_details = DB::table('emp_details')
                ->where('email',  $request->Actual_emp_name)
                ->update([
                    'role' =>   $request->emp_role,
                    'email' => $request->emp_email,
                    'pay_cycle' => $request->emp_pay_cycle,
                    'gross_pay' => $request->emp_gross_pay,
                    'rate' => $request->emp_rate
                ]);
            $company_id = Auth::user()->id;
            $employees = EmpDetail::where('user_id',$company_id)->get();
            $employees = (json_decode($employees));

            $data = [];
            $temp =[];
            foreach ($employees as $employee)
            {
                $users = User::where('id',$employee->user_id)->get();
                $users = (json_decode($users));

                foreach ($users as $user)
                {
                    $temp = array(
                        "id"=>$employee->id,
                        "name"=>$user->name,
                        "role"=>$employee->role,
                        "email"=>$employee->email,
                        "picture"=>$employee->pic
                    );
                }
                array_push($data, $temp);
            }
            return view('add_employee.viewEmp')->with('message','Employee ID: '. $request->emp_id .' Employee Updated.')->with('datas',$data);
        }
        public function deleteEmp(Request $request)
        {
            $company_id = Auth::user()->id;
            $employees = EmpDetail::where('user_id',$company_id)->get();
            $employees = (json_decode($employees));

            $data = [];
            $temp =[];
            foreach ($employees as $employee)
            {
                $users = User::where('id',$employee->user_id)->get();
                $users = (json_decode($users));

                foreach ($users as $user)
                {
                    $temp = array(
                        "id"=>$employee->id,
                        "name"=>$user->name,
                        "role"=>$employee->role,
                        "email"=>$employee->email,
                        "picture"=>$employee->pic
                    );
                }
                array_push($data, $temp);
            }
            // dash board function
            return view('add_employee.viewEmp')->with('message','Employee ID: '. $request->emp_id .' Employee Deleted.')->with('datas',$data);
        }

        public function store(Request $request)
        {
            $name = $request->name;
            $email = $request->email;
            $pass = $request->pass;
            $pass = Hash::make($pass);
            $type = $request->type;

            $result = [];
            $user = User::where("email", $email)->get();

            if (empty(json_decode($user))) {
                $u = new User();
                $u->name = $name;
                $u->email = $email;
                $u->password = $pass;
                $u->type = $type;

                $save = $u->save();
                if ($save) {

                    $result = array(
                        "code" => "1",
                        "data" => "$email",
                        "response" => 'User added!'
                    );
                } else {
                    $result = array(
                        "code" => "0",
                        "data" => "$email",
                        "response" => 'Somthing went Wrong Please Try Again!'
                    );
                }
            } else {
                $result = array(
                    "code" => "0",
                    "data" => "$email",
                    "response" => 'User Already Exists!'
                );

            }
            return json_encode($result);
        }

        public function other_emp_details(Request $request)
        {
            $role = $request->role;
            $PayCycle = $request->PayCycle;
            $disabledEmail = $request->disabledEmail;
            $gross_pay = $request->gross_pay;
            $rate = $request->rate;
            $types_of_deduction = implode(',', $request->types_of_deduction);
            $company_id = Auth::user()->id;
            $result = array();
            $flag = false;
    //profile pic
            $profile_pic = $request->file('empProfilePic');
            $new_name_arry = explode('@', $disabledEmail);
            $profile_pic_extension = $profile_pic->getClientOriginalExtension();
            $new_name = $new_name_arry[0] . '_' . rand() . '.' . $profile_pic_extension;
            $profile_pic->move(public_path("images"), $new_name);
    //\\Endprofile pic
            $emp_details = DB::table('emp_details')->insertGetId(
                [
                    'user_id' => $company_id,
                    'email' => $disabledEmail,
                    'role' => $role,
                    'pic' => $new_name,
                    'pay_cycle' => $PayCycle,
                    'gross_pay' => $gross_pay,
                    'rate' => $rate,
                    'deductions' => $types_of_deduction
                ]
            );

            if (!empty($emp_details)) {
                $types_of_deductionArry = explode(',', $types_of_deduction);
                for ($i = 0; $i < sizeof($types_of_deductionArry); $i++) {
                    DB::table('deductions')->insert([
                        'emp_detail_id' => $emp_details,
                        'name' => $types_of_deductionArry[$i],
                        'type' => '$',
                        'amount' => '0.00'
                    ]);
                }
                $result = array(
                    "code" => "1",
                    "data" => $emp_details,
                    "response" => 'Employee Details added!'
                );
            } else {
                $result = array(
                    "code" => "0",
                    "data" => "",
                    "response" => 'Employee Email Exists!'
                );
            }
            return json_encode($result);
        }

        function deductionForm(Request $request)
        {
            $current_emp_id = $request->id;


            $emp_details = Deduction::where('emp_detail_id', $current_emp_id)->get();


            return view('add_employee.deductionForm')->with('results', $emp_details);
        }

        public function updateDeduction(Request $request)
        {

            for ($i = 0; $i <sizeof($request->id); $i++)
            {

                $deduc = DB::table('deductions')
                    ->where('id',  $request->id[$i])
                    ->update([
                        'type' =>   $request->type[$i],
                        'amount' => $request->amount[$i]
                ]);
            }

            return view('dashboard');
        }

        public function pickUsersCalcPay(Request $request)
        {
            $temp =[];
            $data=[];

            foreach($request->request as $key => $value)
            {
                if ($value == 'on')
                {
                    $empdetails = EmpDetail::where('id',$key)->get();
                    $empdetails = (json_decode($empdetails));

                    foreach ($empdetails as $empdetail)
                    {
                        $temp = array(
                            "id"=>$empdetail->id,
                            "role"=>$empdetail->role,
                            "email"=>$empdetail->email,
                            "picture"=>$empdetail->pic,
                            "pay_cycle"=>$empdetail->pay_cycle
                        );
                    }
                        array_push($data, $temp);
                    }
            }

            return view('add_employee.ifAnyabsents')->with('datas',$data);
        }

        public function postHoursWorked(Request $request)
        {
            $company_id = Auth::user()->id;

           $numberEmployee = sizeof($request->id);
           $employeePosition = 0;
            $outerLoopCount =0;
            $testArray = array();
            $pay_daily_array = array();
            $perUserTotalhours = 0;
            for ($i=0;$i<$numberEmployee;$i++){
                $innerLoopCount = 0;
                $tempEachEmployeeHour = 0;
                $paycycle = $request->cycle[$employeePosition];
                $userEmail = $request->email[$employeePosition];
                $userDeductionID = $request->id[$employeePosition];
                $from = $request->from[$employeePosition];
                $num_workable_days = 0;
                if ($paycycle == 'weekly') {
                    $num_workable_days = 7;
                }elseif($paycycle == 'forthrightly') {
                    $num_workable_days = 14;
                }

                for($j =0;$j<$num_workable_days;$j++){
                    $daily_hour = $request->hrs[$outerLoopCount];
                    if($daily_hour == null || $daily_hour == 0){
                        $daily_hour = 0;
                        // absent Area

                    }else{
                        // Present Area
                       $pref =  Preference::where('company_id',$company_id)->get();
                       $usr = EmpDetail::where('email',$userEmail)->get();
                        $usr = json_decode($usr);

                       //todo:
                        $normal = 8 ;// todo: get nomal hr per
                        $timeHalfHour = 2; // todo get time half hour db
                        $rate = $usr[0]->rate ; // todo get the rate db
                        $extraHours = $daily_hour - $normal;

                        if ($extraHours <= $normal){ // no extra Hours
                            // just Normal Pay
                            $temp_daily_pay = $daily_hour * $rate;
                            $pay_daily_array[] = $temp_daily_pay;
                        }elseif ($extraHours > $timeHalfHour){ // double Pay
                            // normal pay and time and half and double pay
                            $temp_normal_pay = $normal * $rate;
                            $temp_daily_double_rate =  $extraHours - $timeHalfHour;
                            $temp_half_time_pay = ($rate * 1.5) * $timeHalfHour;
                            $temp_double_pay = ($rate * 2) * $temp_daily_double_rate;
                            $total = $temp_normal_pay + $temp_half_time_pay +$temp_double_pay;
                            $pay_daily_array[] = $total;

                        }elseif ($extraHours < $timeHalfHour){ // Time Half Pay
                            // normal pay and time and half
                            $temp_normal_pay = $normal * $rate;
                            $temp_half_time_pay = ($rate * 1.5) * $timeHalfHour;
                            $total = $temp_normal_pay + $temp_half_time_pay;
                            $pay_daily_array[] = $total;
                        }else{ // some error if it reaches this

                        }
                    }
                    $perUserTotalhours += $daily_hour;
                    $innerLoopCount++;
                    $outerLoopCount++;
                }
                $this->make_pay( array_sum($pay_daily_array),$userEmail, $userDeductionID, $perUserTotalhours,$from,$num_workable_days,$paycycle,$rate,$userEmail) ;
                $employeePosition++;
            }
            return view('dashboard');
        }
        public function make_pay($gross_pay , $email, $userDeductionID ,$perUserTotalhours,$from,$num_workable_days,$paycycle,$rate,$userEmail){
            $usrDetails = EmpDetail::where('email',$email)->get();
            $usrDetails = json_decode($usrDetails);

            $deductionDetails = Deduction::where('emp_detail_id',$userDeductionID)->get();
            $deductionDetails = json_decode($deductionDetails);
            $date = new DateTime($from);
            $date->modify('+'.$num_workable_days.' day');
            $pay_to = $date->format('Y-m-d');
            $net_pay_calc = $gross_pay;

        for($i = 0; $i <sizeof($deductionDetails); $i++)
        {
            $deductionAmount = $deductionDetails[$i]->amount;
            $deductionType = $deductionDetails[$i]->type;
            $deductionName = $deductionDetails[$i]->name;
            if ($deductionType == '%')
            {
                $one = $net_pay_calc * $deductionAmount/100;
                $net_pay_calc = $net_pay_calc - $one;

            }else{
                $net_pay_calc = $net_pay_calc - $deductionAmount;
            }
            $ded[] = $deductionName.':'.$deductionAmount.$deductionType;

        }
            $ded_db = implode(',', $ded);
            DB::table('pays')->insert([
                'gross_pay' =>$gross_pay,
                'net_pay' => $net_pay_calc,
                'hours_worked' => $perUserTotalhours,
                'rate'=>$rate,
                'pay_cycle' => $paycycle,
                'deductions' =>$ded_db,
                    'pay_from' => $from,
                'pay_to' => $pay_to,
                'email'=>$userEmail
            ]);


        }
   /*     public function calculate_pay($HoursWorked,$email){
            //ate_pay(40,'hehiwemaca@mailinator.net');
            $usrDetails = EmpDetail::where('email',$email)->get();
            $usrDetails = json_decode($usrDetails);
            $rate = (float)$usrDetails[0]->rate;
            $deductionAmounts = array();
            $gross_pay = $HoursWorked * $rate;

            $deductions = explode(',', $usrDetails[0]->deductions);
            $deduction_id = 10;
            $allDeductions = Deduction::where('emp_detail_id',$deduction_id)->get();
            $allDeductions = json_decode($allDeductions);
            foreach ($allDeductions as $deduction){
                $type = $deduction->type;
                if($type == '$'){
                    $deductionAmounts[] = $deduction->amount;
                }elseif ($type == '%'){
                    $tempDeduct = $deduction->amount/100 * $gross_pay;
                    $deductionAmounts[] = $tempDeduct;
                }
            }

            $total_deduction = 0;
            foreach ($deductionAmounts as $deduction){
                $total_deduction = $total_deduction + $deduction;
            }
            $net_pay = $gross_pay - $total_deduction;

        }*/

    }//end